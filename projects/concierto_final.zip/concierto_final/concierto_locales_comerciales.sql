-- MySQL dump 10.13  Distrib 8.0.17, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: concierto
-- ------------------------------------------------------
-- Server version	8.0.17

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `locales_comerciales`
--

DROP TABLE IF EXISTS `locales_comerciales`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `locales_comerciales` (
  `local_id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre_local` varchar(45) NOT NULL,
  `zona_id` int(11) NOT NULL,
  `costo_renta` varchar(45) NOT NULL,
  `fecha_pago` varchar(45) NOT NULL,
  PRIMARY KEY (`local_id`),
  KEY `local_zona_idx` (`zona_id`),
  CONSTRAINT `local_zona` FOREIGN KEY (`zona_id`) REFERENCES `zonas` (`zona_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `locales_comerciales`
--

LOCK TABLES `locales_comerciales` WRITE;
/*!40000 ALTER TABLE `locales_comerciales` DISABLE KEYS */;
INSERT INTO `locales_comerciales` VALUES (1,'tacos_hoy',1,'1100','01-12-2020'),(2,'burritos',2,'1100','01-12-2020'),(3,'chelas',3,'1100','01-12-2020'),(4,'nieves',4,'1100','01-12-2020'),(5,'chelas-2',5,'1100','01-12-2020'),(6,'nieves-2',6,'1400','01-12-2020'),(7,'chelas-3',7,'1400','01-12-2020'),(8,'burritos-2',8,'1400','01-12-2020'),(9,'tacos-1',9,'2000','01-12-2020'),(10,'hotdog',1,'2000','01-12-2020');
/*!40000 ALTER TABLE `locales_comerciales` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-08-29 23:59:14
