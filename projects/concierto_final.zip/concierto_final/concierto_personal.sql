-- MySQL dump 10.13  Distrib 8.0.17, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: concierto
-- ------------------------------------------------------
-- Server version	8.0.17

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `personal`
--

DROP TABLE IF EXISTS `personal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `personal` (
  `personal_id` int(11) NOT NULL AUTO_INCREMENT,
  `personal_nombre` varchar(45) NOT NULL,
  `personal_apellido` varchar(45) NOT NULL,
  `puesto` varchar(45) NOT NULL,
  PRIMARY KEY (`personal_id`)
) ENGINE=InnoDB AUTO_INCREMENT=101 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personal`
--

LOCK TABLES `personal` WRITE;
/*!40000 ALTER TABLE `personal` DISABLE KEYS */;
INSERT INTO `personal` VALUES (1,'Gill','Ruppertz','Suzuki'),(2,'Cinderella','Fuge','Land Rover'),(3,'Perceval','Longfellow','Oldsmobile'),(4,'Anestassia','Balhatchet','Mercury'),(5,'Nani','D\'Alessandro','GMC'),(6,'Eliot','Dunnett','Cadillac'),(7,'Cherilynn','Coarser','Chevrolet'),(8,'Ronnica','Smaile','Dodge'),(9,'Lila','Ribou','Nissan'),(10,'Laura','Bache','Geo'),(11,'Emlen','Rogier','Ford'),(12,'Alanson','Wilmott','Oldsmobile'),(13,'Aylmar','Arunowicz','Ford'),(14,'Luci','Burle','Chevrolet'),(15,'Sallyanne','Iacobo','Ford'),(16,'Madelena','Dewett','Dodge'),(17,'Lindsey','Pasley','Lincoln'),(18,'Ardelle','Brompton','Ford'),(19,'Nat','Tuting','BMW'),(20,'Hollie','Brearton','Ford'),(21,'Brent','Pender','Maserati'),(22,'Jody','Mazdon','Saab'),(23,'Pauly','Greenhill','Acura'),(24,'Melli','Soppit','Porsche'),(25,'Perla','Kynston','Mercury'),(26,'Tomas','Labone','Mercury'),(27,'Stafford','Hutcheon','Land Rover'),(28,'Sinclare','Sharram','Chevrolet'),(29,'Amberly','Dodwell','Porsche'),(30,'Farrand','Picheford','Ford'),(31,'Debbi','Skayman','Ford'),(32,'Asher','Gerrard','Mazda'),(33,'Nanny','Cabera','Mazda'),(34,'Abbot','Kindleysides','Lincoln'),(35,'Chariot','Stanistrete','Chevrolet'),(36,'Mehetabel','Milham','Kia'),(37,'Pippy','Coleson','Nissan'),(38,'Eberhard','Rosetti','Suzuki'),(39,'Dougie','Larter','Spyker'),(40,'Wilhelmina','Sherlock','GMC'),(41,'Derby','Goodhall','Porsche'),(42,'Gavin','Cockayme','Pontiac'),(43,'Noami','Vickars','Maybach'),(44,'Melina','Braunle','Maserati'),(45,'Mort','Vaune','Volkswagen'),(46,'Giselbert','Newdick','Pontiac'),(47,'Wallace','Gladtbach','Mitsubishi'),(48,'Lee','Aberkirdo','Cadillac'),(49,'Craggie','Cuppleditch','Porsche'),(50,'Idelle','Addeycott','Chevrolet'),(51,'Hilario','Frank','Mazda'),(52,'Asa','Showl','Mercedes-Benz'),(53,'Ceciley','Dalgliesh','Dodge'),(54,'Michal','Dayly','Porsche'),(55,'Porty','Ladbrook','BMW'),(56,'Maryjo','O\'Cannovane','BMW'),(57,'Sunny','Micheau','Mitsubishi'),(58,'Ebony','Parkeson','Mercury'),(59,'Dyna','Lamort','Nissan'),(60,'Cynthea','Sackey','Hyundai'),(61,'Duke','Leigh','Geo'),(62,'Gene','Trees','Jaguar'),(63,'Tabbie','Yannoni','Hyundai'),(64,'Shanna','Finicj','Honda'),(65,'Jerry','Abrahami','Volkswagen'),(66,'Birgit','Kleinplatz','Nissan'),(67,'Anson','Jervoise','Ford'),(68,'Hermine','D\'Ambrogi','Toyota'),(69,'Sabina','Teas','Lotus'),(70,'Edgar','Casaroli','Chevrolet'),(71,'Aldo','Sherborn','Dodge'),(72,'Celle','Skyrme','Pontiac'),(73,'Debbi','Birkenhead','Nissan'),(74,'Cindra','Vasyukhin','Nissan'),(75,'Clemmy','Cottam','Volvo'),(76,'Agnesse','Patty','Chevrolet'),(77,'Corie','Kelwick','Dodge'),(78,'Annmaria','Blackborn','BMW'),(79,'Aura','Bourrel','Pontiac'),(80,'Cassy','Le Fevre','Pontiac'),(81,'Cordey','Double','Dodge'),(82,'Teri','Swannick','Chevrolet'),(83,'Heddie','O\'Clery','Chevrolet'),(84,'Mariele','Phillp','Lincoln'),(85,'Dougie','Alderwick','BMW'),(86,'Annabelle','Caslake','Porsche'),(87,'Susannah','Hobell','Mercury'),(88,'Oneida','Fawdrey','Toyota'),(89,'Francois','Chapman','Hyundai'),(90,'Doti','Siviter','Lincoln'),(91,'Rosalind','Valek','BMW'),(92,'Mozes','Mateo','Mazda'),(93,'Kinna','Roz','Chevrolet'),(94,'Kenton','Springford','Audi'),(95,'Oberon','Marcome','Lexus'),(96,'Babbette','Cosstick','Lotus'),(97,'Allx','Fearne','Volkswagen'),(98,'Korella','Strete','Dodge'),(99,'Valentin','Gilardi','Toyota'),(100,'Jarad','Dobbins','Audi');
/*!40000 ALTER TABLE `personal` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-08-29 23:59:17
