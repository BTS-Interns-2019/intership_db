CREATE DATABASE  IF NOT EXISTS `concierto` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `concierto`;
-- MySQL dump 10.13  Distrib 8.0.17, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: concierto
-- ------------------------------------------------------
-- Server version	8.0.17

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Temporary view structure for view `palcos_disponibles`
--

DROP TABLE IF EXISTS `palcos_disponibles`;
/*!50001 DROP VIEW IF EXISTS `palcos_disponibles`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `palcos_disponibles` AS SELECT 
 1 AS `palco id disponible`,
 1 AS `zona`*/;
SET character_set_client = @saved_cs_client;

--
-- Final view structure for view `palcos_disponibles`
--

/*!50001 DROP VIEW IF EXISTS `palcos_disponibles`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `palcos_disponibles` AS select `palcos`.`palcos_id` AS `palco id disponible`,`palcos`.`zona` AS `zona` from `palcos` where `palcos`.`palcos_id` in (select `p`.`palco_id` from `palcos_vendidos` `p`) is false */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Dumping events for database 'concierto'
--

--
-- Dumping routines for database 'concierto'
--
/*!50003 DROP FUNCTION IF EXISTS `asientos_disponibles` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `asientos_disponibles`(zona INT) RETURNS int(11)
    DETERMINISTIC
BEGIN
return (SELECT zonas.espacios_zona - count(boletos.numero_asiento) AS Espacios_disponibles	FROM boletos 
	JOIN zonas ON zonas.zona_id = boletos.zona_id
	JOIN ventas_boletos ON ventas_boletos.boleto_id = boletos.boleto_id
    WHERE zonas.zona_id = zona);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `cuanto_baro_falta` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `cuanto_baro_falta`(evento INT) RETURNS int(11)
    DETERMINISTIC
BEGIN
	SELECT evento.precio_evento FROM evento WHERE evento_id = evento INTO @costo_evento;
    
	(SELECT SUM(precio_boleto.precio) AS total
		INTO @total
            FROM precio_boleto
            JOIN ventas_boletos ON ventas_boletos.precio_boleto_id = precio_boleto.precio_boleto_id
            JOIN zonas ON zonas.zona_id = precio_boleto.zona_id
            JOIN evento ON evento.evento_id = zonas.evento_id
            WHERE zonas.evento_id = evento);
            

RETURN @costo_evento - @total;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `asientos_ocupados` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `asientos_ocupados`(seccion INT)
BEGIN
		SELECT boletos.numero_asiento AS NumeroAsiento
	FROM boletos 
	JOIN zonas ON zonas.zona_id = boletos.zona_id
	JOIN ventas_boletos ON ventas_boletos.boleto_id = boletos.boleto_id
    WHERE zonas.zona_id = seccion
	ORDER BY boletos.boleto_id;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `desglose_factura` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `desglose_factura`(idfactura int)
BEGIN
select facturacion.fecha AS FECHA_FACTURA, ventas_boletos.fecha_venta as FECHA_VENTA,
CONCAT(clientes.nombre, ' ',clientes.apellido) as NOMBRE,
evento.nombre_evento as EVENTO, zonas.nombre_zona as ZONA,
 precio_boleto.tipo_boleto as TIPO_BOLETO,
precio_boleto.precio AS PRECIO, promocion.precio as 'DESCUENTO(%)',
 sum(precio_boleto.precio - precio_boleto.precio*promocion.precio/100) AS TOTAL 
from facturacion
join ventas_boletos on ventas_boletos.factu_id = facturacion.factura_id
join precio_boleto on ventas_boletos.precio_boleto_id = precio_boleto.precio_boleto_id
join tipo_pago on tipo_pago.tipo_pago_id  = ventas_boletos.tipo_pago_id
join boletos on boletos.boleto_id = ventas_boletos.boleto_id
join promocion on promocion.promo_id = tipo_pago.promocion_id
join clientes on ventas_boletos.cliente_id = clientes.cliente_id
join zonas on precio_boleto.zona_id = zonas.zona_id
join evento on zonas.evento_id = evento.evento_id
where factura_id = idfactura
GROUP BY boletos.boleto_id
with rollup;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-08-30 16:59:03
